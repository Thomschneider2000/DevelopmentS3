var video;
var scaler = 20;
var preFrame;
let detector;
let detections = [];

function preload() {
  detector = ml5.objectDetector('cocossd');
}

function gotDetections(error, results) {
  if (error) {
    console.error(error);
  }
  //console.log(results);
  detections = results;
  detector.detect(video, gotDetections);
}

function setup() {
  createCanvas(1920, 1080);
  pixelDensity(1);
  video = createCapture(VIDEO);
  //console.log("tekst");
  video.size(1920/ scaler, 1080 / scaler);
  video.hide();
  preFrame = createImage(video.width, video.height);
  detector.detect(video, gotDetections);
  document.getElementById("popupImg").style.visibility = "hidden";
}

function draw() {
  video.loadPixels();
  preFrame.loadPixels();
  document.getElementById("popupImg").style.visibility = "hidden";

  for (let y = 0; y < video.height; y++) {
    for (let x = 0; x < video.width; x++) {
      var index = (x + y * video.width) * 4
      let pr = preFrame.pixels[index + 0];
      let pg = preFrame.pixels[index + 1];
      let pb = preFrame.pixels[index + 2];

      let r = video.pixels[index + 0];
      let g = video.pixels[index + 1];
      let b = video.pixels[index + 2];
      let bright = (r + g + b) / 50;
			
      var diff = dist(r, g, b, pr, pg, pb);
			if (diff<20){
        fill(bright);
      } else {
        fill(255, 255, 0);
      }
      noStroke();
      rect(x * scaler, y * scaler, scaler, scaler);
    }
  }

  for (let i = 0; i < detections.length; i++) {
    let object = detections[i];
    if (object.label == 'person'){
      //console.log("Persoon gedetecteerd");
      document.getElementById("popupImg").style.visibility = "visible";
    }
  }
    preFrame.copy(video, 0, 0, video.width, video.height, 0, 0, video.width, video.height);
}
